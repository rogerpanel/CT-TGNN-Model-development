"""Training modules for CT-TGNN."""

from .trainer import Trainer

__all__ = ['Trainer']
