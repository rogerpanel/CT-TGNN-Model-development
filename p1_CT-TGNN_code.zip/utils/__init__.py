"""Utility modules for CT-TGNN."""
